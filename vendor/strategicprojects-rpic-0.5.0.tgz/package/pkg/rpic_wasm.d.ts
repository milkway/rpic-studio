/* tslint:disable */
/* eslint-disable */

/**
 * Compile pic source to a JSON `{svg, animations, diagnostics}` bundle (or
 * `{error}`).
 */
export function compile(src: string): string;

/**
 * Like [`compile`], but with the native circuit-element library prepended
 * (so `resistor`, `and_gate`, … are available).
 */
export function compile_circuits(src: string): string;

/**
 * Like [`compile`], with options: `circuits` prepends the circuit-element
 * library; `texlabels` sets `texlabels = 1` so `$…$` labels are typeset as
 * TeX math. Note: the default wasm build ships without the math renderer
 * (size budget), so with `texlabels` the labels fall back to literal text
 * and a diagnostic — use the math-enabled build (`--features math`, the
 * `rpic_wasm_math` npm artifact) to typeset them.
 */
export function compile_with(src: string, circuits: boolean, texlabels: boolean): string;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly compile: (a: number, b: number) => [number, number];
    readonly compile_circuits: (a: number, b: number) => [number, number];
    readonly compile_with: (a: number, b: number, c: number, d: number) => [number, number];
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
